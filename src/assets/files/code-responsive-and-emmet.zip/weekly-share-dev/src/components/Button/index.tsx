import './index.scss';

type Props = {};

function Button({}: Props) {
  return (
    <div className="button">This is a button</div>
  );
}

export default Button;