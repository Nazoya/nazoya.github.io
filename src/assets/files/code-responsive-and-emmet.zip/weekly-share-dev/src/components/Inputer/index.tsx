"use client";

import Head from 'next/head';
import { useEffect } from 'react';

type Props = {}

function Inputer({ }: Props) {
  function setViewportHeight() {
    let vh = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--inner-vh', `${vh}px`);
  }

  // 注：条件允许，应该把示例代码移至框架外尽早执行
  useEffect(() => {
    window.addEventListener('resize', setViewportHeight);
    window.addEventListener('orientationchange', setViewportHeight);
    setViewportHeight();

    return () => {
      window.removeEventListener('resize', setViewportHeight);
      window.removeEventListener('orientationchange', setViewportHeight);
    };
  }, []);

  return (
    <>
      <Head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0,interactive-widget=resizes-content" />
      </Head>
      <main className='flex flex-col h-[calc(var(--inner-vh,1vh)*100)] bg-slate-200'>
        <header className='flex justify-center items-center h-48 flex-none text-6xl text-center py-4 px-9 bg-white border-b-2'>导航栏</header>
        <section className='flex-1'></section>
        <div id="wrapper" className='flex-none px-12 py-8 text-4xl bg-slate-300 flex flex-wrap gap-4 items-center'>
          <label htmlFor='text'>
            text:
          </label>
          <input
            id='text'
            placeholder='please input your text'
            type='text'
            className='inline-block px-4 py-4 flex-1 max-w-full'
          />
        </div>
      </main>
    </>
  );
}

export default Inputer;