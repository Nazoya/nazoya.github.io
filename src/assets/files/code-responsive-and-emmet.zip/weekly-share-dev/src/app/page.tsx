import Button from '../components/Button';

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-24">
      <Button />

      {/* 可以通过 Command/Ctrl + / 解开每段的最后一行的注释，尝试使 Command/Ctrl + I 或其他组合键进行 Emmet 联想，查看下生成效果。 */}
      
      {/* ———————————————— 基本语法 ———————————————————— */}
      {/* 开闭标签 */}
      {/* 生成前：ul */}
      {/* ul */}

      {/* 单闭合标签 / */}
      {/* 生成前：ul/ */}
      {/* ul/ */}
      
      {/* 后代标签 > */}
      {/* 生成前：ul>li */}
      {/* ul>li */}

      {/* 相邻节点标签 + */}
      {/* 生成前：ul+form */}
      {/* ul+form */}

      {/* 爬升 ^ */}
      {/* 生成前：ul>li^form */}
      {/* ul>li^form */}

      {/* 多个元素 *N */}
      {/* 生成前：ul>li*100 */}
      {/* ul>li*100 */}

      {/* 组合 () */}
      {/* 生成前：ul>li>(span+a+span) */}
      {/* ul>li>(span+a+span) */}

      {/* 文本 {} */}
      {/* 生成前：ul>li{text content} */}
      {/* ul>li{text content} */}

      {/* 类 . */}
      {/* 生成前：ul.list-none>li.text-grey-500{some text in li} */}
      {/* ul.list-none>li.text-grey-500{some text in li} */}

      {/* ID # */}
      {/* 生成前：ul.list-none>li#list-el */}
      {/* ul.list-none>li#list-el */}

      {/* 属性 [] */}
      {/* 生成前：ul>li[data-id=el]>(span+a+span) */}
      {/* ul>li[data-id=el]>(span+a+span) */}

      {/* 动态数字 $ */}
      {/* 生成前：ul>li[data-id=$]*10 */}
      {/* ul>li[data-id=$]*10 */}

      {/* 动态数字（格式化） $$$ 任意$ */}
      {/* 生成前：ul>li[data-id=$$$]*10 */}
      {/* ul>li[data-id=$$$]*10 */}

      {/* 动态数字（指定起始） $@ */}
      {/* 生成前：ul>li[data-id=$$$@10]*10 */}
      {/* ul>li[data-id=$$$@10]*10 */}

      {/* 动态数字（逆序） $@- */}
      {/* 生成前：ul>li[data-id=$$@-]*10 */}
      {/* ul>li[data-id=$$@-]*10 */}

      {/* 动态数字（组合使用） $@ */}
      {/* 生成前：ul>li[data-id=$-$$@-10]*10 */}
      {/* ul>li[data-id=$-$$@-10]*10 */}

      {/* 结合 tailwindcss 使用，组合语法 */}
      {/* 生成前：ul.list-none>li.text-grey-500{some text in li} */}
      {/* ul.list-none>li.text-grey-500{some text in li} */}


      {/* —————————————————————— 常用生成 —————————————————————————— */}

      {/* 生成前：input:s */}
      {/* input:s */}

      {/* 生成前：input:b */}
      {/* input:b */}

      {/* 生成前：input:color */}
      {/* input:color */}
      
      {/* 生成前：input:checkbox */}
      {/* input:checkbox */}

      {/* 生成前：button:s */}
      {/* button:s */}

      {/* 生成前：button:b */}
      {/* button:b */}

      {/* 生成前：Button */}
      {/* Button */}

      {/* 生成前：Button/+Button/ */}
      {/* Button/+Button/ */}

      {/* 生成前：lorem */}
      {/* lorem */}

      {/* 生成前：form:get */}
      {/* form:get */}

      {/* 生成前：form:post */}
      {/* form:post */}

      {/* 生成前：div[className="text-red-500"]{Put your text here}/ */}
      {/* div[className="text-red-500"]{Put your text here}/ */}
      
      {/* 终极组合： */}
      {/* 生成前：header>nav>ul.list-none.flex.justify-start.gap-2.text-blue-400>(li>a{$$$@-10}[href=/other/$$$@-10])*10^^^(main>section*{text}) */}
      {/* header>nav>ul.list-none.flex.justify-start.gap-2.text-blue-400>(li>a{$$$@-10}[href=/other/$$$@-10])*10^^^(main>section*{text}) */}
    </main>
  );
}
