import Inputer from '@/components/Inputer';


export default function Page() {
  return (
    <Inputer />
  );
}