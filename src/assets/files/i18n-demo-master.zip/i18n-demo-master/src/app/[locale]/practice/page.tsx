import { useTranslations } from 'next-intl';
import { getTranslations } from 'next-intl/server';

export async function generateMetadata(
  { params: { locale } }: { params: { locale: string } }
) {
  const t = await getTranslations({ locale });

  return {
    title: t('HomePage.title'),
  };
}

export default function Page() {
  const count = 0;
  console.info(count);
  const t = useTranslations();
  
  return (
    <main>
      <article>
        <h1>Heading 1</h1>
        <h2>Heading 2</h2>
        <p>
          {
            // t("calm_acidic_pig_bask",{ num_guests: count, gender_of_host: "male", host: "Jack", guest: "Prince" })
            t(
              "calm_acidic_pig_bask",
              { num_guests: count, gender_of_host: "male", host: "Jack", guest: "Prince" },
            )
          }
        </p>
        <h2>Heading 2</h2>
        <h2>Heading 2</h2>
        <h2>Heading 2</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veritatis accusantium tempora repellendus aliquid quia quis laborum. Praesentium voluptate quos consequuntur mollitia fugit repellendus laboriosam quis, reprehenderit, voluptatem assumenda eos nostrum.</p>
        <h3>Heading 3</h3>
        <p>Your browser does not support the video tag.</p>
        <p>Your browser does not support the video tag.</p>
        <p>Your browser does not support the script tag.</p>
        <p>Your browser does not support the script tag.</p>
      </article>
    </main>
  );
}